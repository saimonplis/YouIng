/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Matteo
 */
public class AbbonamentoTest {
    
    Abbonamento abbonamento;
    
    public AbbonamentoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp(){
        abbonamento = new Abbonamento();
    }

    /**
     * Test of verifica method, of class Abbonamento.
     */
    @Test
    public void testVerifica() {
        System.out.println("verifica");
        //Abbonamento instance = new Abbonamento();
        Boolean expResult = true;
        Boolean result = abbonamento.verifica();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
}
