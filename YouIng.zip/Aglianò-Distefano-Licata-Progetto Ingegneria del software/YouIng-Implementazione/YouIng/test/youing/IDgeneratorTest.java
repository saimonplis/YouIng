/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Matteo
 */
public class IDgeneratorTest {
    
    Integer idVideo;
    Integer idUtente;
    IDgenerator idGen;
    
    public IDgeneratorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp(){
        idGen = new IDgenerator();
        idVideo = 0;
        idUtente = 0;
    }

    /**
     * Test of calcolaIDvideo method, of class IDgenerator.
     */
    @Test
    public void testCalcolaIDvideo() {
        System.out.println("calcolaIDvideo");
        Integer expResult = 1;
        Integer result = idGen.calcolaIDvideo();
        assertEquals(expResult, result);
    }

    /**
     * Test of calcolaIDutente method, of class IDgenerator.
     */
    @Test
    public void testCalcolaIDutente() {
        System.out.println("calcolaIDutente");
        Integer expResult = 1;
        Integer result = idGen.calcolaIDutente();
        assertEquals(expResult, result);
    }
}