/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import java.io.File;
import junit.framework.Assert;
import static org.junit.Assert.*;
import org.junit.*;

/**
 *
 * @author Matteo
 */
public class VideoTest {
    
    Categoria cat;
    GestoreUtente gestUten;
    Video video;
    File videoContent;
    SezioneVideo sezVid;
    
    public VideoTest() {
        
    }
    
    @Before
    public void setUpClass() {
        video = new Video("Video_1", "Commedia", 1);
        cat = new Categoria("Istruzione");
        gestUten = new GestoreUtente();
        videoContent = new File("VideoUtente");
        sezVid = new SezioneVideo();
    }
    
    @AfterClass
    public static void tearDownClass(){
    }

    /**
     * Test of setContent method, of class Video.
     */
    @Test
    public void testSetContent() {
        System.out.println("setContent");
        video.setContent(videoContent);
        assertEquals(videoContent, video.getContent());
    }

    /**
     * Test of setUtente method, of class Video.
     */
    @Test
    public void testSetUtente() {
        System.out.println("setUtente");
        String nomeUtente = "Matteo";
        assertEquals(nomeUtente,gestUten.getNomeUtente());
    }

    /**
     * Test of getCategoria method, of class Video.
     */
    @Test
    public void testGetCategoria() {
        System.out.println("getCategoria");
        Categoria expResult = cat;
        video.setCategoria(cat);
        Categoria result = video.getCategoria();
        assertEquals(expResult, result);
    }

    /**
     * Test of setCategoria method, of class Video.
     */
    @Test
    public void testSetCategoria(){
        System.out.println("setCategoria");
        video.setCategoria(cat);
        Categoria expRedult = cat;
        Categoria result = video.getCategoria();
        assertEquals(expRedult, result);
    }

    /**
     * Test of riepilogo method, of class Video.
     */
    @Test
    public void testRiepilogo() {
        System.out.println("riepilogo");
        String expResult = "Nome file: Video_1"+"\n"+ "Descrizione: Commedia";
        String result = video.riepilogo();
        assertEquals(expResult, result);
    }

    /**
     * Test of showUserVideo method, of class Video.
     */
    @Test
    public void testShowUserVideo() {
        System.out.println("showUserVideo");
        String expResult = "Video_1"+"Matteo";
        video.setUtente("Matteo");
        String result = video.showUserVideo();
        assertEquals(expResult, result);
    }

    /**
     * Test of toString method, of class Video.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
        String expResult = "Video_1";
        String result = video.toString();
        assertEquals(expResult, result);
    }
}