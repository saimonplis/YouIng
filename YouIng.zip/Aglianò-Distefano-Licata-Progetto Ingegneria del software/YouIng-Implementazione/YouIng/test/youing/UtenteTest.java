/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Matteo
 */
public class UtenteTest {
    
    Abbonamento abbonamento, abbonamento_failed;
    Utente utente_abbonato, utente_free;
    
    public UtenteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp(){
        abbonamento_failed = null;
        utente_abbonato = new Utente("Matteo", "1233", "abc@email.it", abbonamento);
        utente_free = new Utente("Matteo", "1233", "abc@email.it", abbonamento_failed);
    }

    /**
     * Test of getAbbonamento method, of class Utente.
     */
    @Test
    public void testGetAbbonamento() {
        System.out.println("getAbbonamento");
        Abbonamento expResult = abbonamento;
        Abbonamento result = utente_abbonato.getAbbonamento();
        assertEquals(expResult, result);
    }
    
    @Test
    public void testGetAbbonamentoFailed(){
        System.out.println("getAbbonamentoFailed");
        Abbonamento expResult = abbonamento_failed;
        Abbonamento result = utente_free.getAbbonamento();
        assertEquals(expResult, result);
    }

    /**
     * Test of getNomeUtente method, of class Utente.
     */
    @Test
    public void testGetNomeUtente() {
        System.out.println("getNomeUtente");
        String expResult = "Matteo";
        String result = utente_abbonato.getNomeUtente();
        assertEquals(expResult, result);
    }
}