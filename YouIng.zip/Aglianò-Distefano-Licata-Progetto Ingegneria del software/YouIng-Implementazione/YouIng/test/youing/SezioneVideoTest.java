/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Matteo
 */
public class SezioneVideoTest {
    
    SezioneVideo sezioneVideo;
    Video video_corrente;
    File videoContent;
    
    public SezioneVideoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp(){
        sezioneVideo = new SezioneVideo();
    }

    /**
     * Test of entraSezionePremium method, of class SezioneVideo.
     */
    @Test
    public void testEntraSezionePremium() {
        System.out.println("entraSezionePremium");
        sezioneVideo.entraSezionePremium();
        Catalogo expResult = sezioneVideo.getCatalogo().get(0);
        Catalogo result = sezioneVideo.getCatalogoCorrente();
        assertEquals(expResult, result);
    }

    /**
     * Test of entraSezioneStandard method, of class SezioneVideo.
     */
    @Test
    public void testEntraSezioneStandard(){
        System.out.println("entraSezioneStandard");
        sezioneVideo.entraSezioneStandard();
        Catalogo expResult = sezioneVideo.getCatalogo().get(1);
        Catalogo result = sezioneVideo.getCatalogoCorrente();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCatalogoCorrente method, of class SezioneVideo.
     */
    @Test
    public void testGetCatalogoCorrente() {
        System.out.println("getCatalogoCorrente");
        sezioneVideo.entraSezionePremium();
        Catalogo expResult = sezioneVideo.getCatalogo().get(0);
        Catalogo result = sezioneVideo.getCatalogoCorrente();
        assertEquals(expResult, result);
    }

    /**
     * Test of getCatalogo method, of class SezioneVideo.
     */
    @Test
    public void testGetCatalogo() {
        System.out.println("getCatalogo");
    }

    /**
     * Test of CercaVideo method, of class SezioneVideo.
     */
    @Test
    public void testCercaVideo() {
        System.out.println("CercaVideo");
        String ParolaChiave = "Thor";
        sezioneVideo.entraSezionePremium();
        Map<Categoria, List<Video>> expResult = sezioneVideo.getCatalogoCorrente().getMapRicerca();
        Map<Categoria, List<Video>> result = sezioneVideo.getCatalogoCorrente().CercaVideo(ParolaChiave);
        assertEquals(expResult, result);
    }

    /**
     * Test of ScegliVideo method, of class SezioneVideo.
     */
    @Test
    public void testScegliVideo(){
        System.out.println("ScegliVideo");
        video_corrente = sezioneVideo.CaricaVideo("VideoUtente", "divertente", 10);
        video_corrente.setContent(videoContent);
        sezioneVideo.entraSezioneStandard();
        
        List<Categoria> expResult = sezioneVideo.getCatalogoCorrente().getCategorie();
        List<Categoria> result = sezioneVideo.ScegliVideo(videoContent);
        assertEquals(expResult, result);
    }

    /**
     * Test of ScegliCategoria method, of class SezioneVideo.
     */
    @Test
    public void testScegliCategoria() {
        System.out.println("ScegliCategoria");
    }

    /**
     * Test of confermaUpload method, of class SezioneVideo.
     */
    @Test
    public void testConfermaUpload() {
        System.out.println("confermaUpload");
    }

    /**
     * Test of CaricaVideo method, of class SezioneVideo.
     */
    @Test
    public void testCaricaVideo() {
        System.out.println("CaricaVideo");
        Video result = sezioneVideo.CaricaVideo("VideoUtente", "divertente", 10);
        Video expResult = sezioneVideo.getVideoCorrente();
        assertEquals(expResult, result);
    }

    /**
     * Test of startStreaming method, of class SezioneVideo.
     */
    @Test
    public void testStartStreaming() {
        System.out.println("startStreaming");
        sezioneVideo.entraSezionePremium();
        sezioneVideo.getCatalogoCorrente().setCategoria("Azione");
        Iterator it = sezioneVideo.CercaVideo("Thor 2").entrySet().iterator();
        ArrayList<Video> tmp;
        Video expResult = null;
        while(it.hasNext()){
            Map.Entry pair = (Map.Entry)it.next();
            tmp = (ArrayList<Video>) pair.getValue();
            expResult = tmp.get(0);
        }
        
        Video result = sezioneVideo.startStreaming(16);
        assertEquals(expResult, result);
    }
}
