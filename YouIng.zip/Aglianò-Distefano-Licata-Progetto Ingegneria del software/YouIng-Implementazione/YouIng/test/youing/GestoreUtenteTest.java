/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

/**
 *
 * @author Matteo
 */
public class GestoreUtenteTest {
    
    Utente utente;
    Abbonamento abbonamento;
    
    public GestoreUtenteTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp(){
        abbonamento = new Abbonamento();
        utente = new Utente("Matteo","1234","abc@email.it",abbonamento);
    }

    /**
     * Test of getNomeUtente method, of class GestoreUtente.
     */
    @Test
    public void testGetNomeUtente() {
        System.out.println("getNomeUtente");
        String expResult = "Matteo";
        String result = utente.getNomeUtente();
        assertEquals(expResult, result);
    }

    /**
     * Test of verificaAbbonamento method, of class GestoreUtente.
     */
    @Test
    public void testVerificaAbbonamento() {
        System.out.println("verificaAbbonamento");
        abbonamento = utente.getAbbonamento();
        Boolean expResult = true;
        Boolean result = abbonamento.verifica(); //mi dà NullPointerException su questo abbonamento
        assertEquals(expResult, result);
    }
}