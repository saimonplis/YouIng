/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import java.util.ArrayList;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Simone
 */
public class CategoriaTest {
    Categoria cat;
    
    public CategoriaTest() {
        
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        cat= new Categoria("Azione");
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of Search method, of class Categoria.
     */
    @Test
    public void testSearch() {
        cat.setVideo("Thor1", "azione", 15);
        cat.setVideo("Thor2", "azione", 16);
        System.out.println("Search");
        String ParolaChiave = "Thor";
        List<Video> expResult = cat.getListaVideo();
        List<Video> result = cat.Search(ParolaChiave);
        assertEquals(expResult, result);
    }
    
    @Test
    public void testSearchFailed(){
        System.out.println("SearchFailed");
        cat.setVideo("Thor1", "azione", 15);
        cat.setVideo("Thor2", "azione", 16);
        String ParolaChiave = "ABC";
        List<Video> expResult = cat.getListaVideoRicerca();
        List<Video> result = cat.Search(ParolaChiave);
        assertEquals(expResult, result);
    }

    /**
     * Test of setVideo method, of class Categoria.
     */
    @Test
    public void testSetVideo() {
        System.out.println("setVideo");
        String nomeVideo = "Thor1";
        String descrizione = "azione";
        Integer idVideo = 15;
       Video expectedResult=new Video("Thor1","azione",15);
        cat.setVideo(nomeVideo, descrizione, idVideo);
        Video result=cat.getVideo(nomeVideo);
        assertEquals(result,cat.getVideo(nomeVideo));
    }

    /**
     * Test of aggiungiVideo method, of class Categoria.
     */
    @Test
    public void testAggiungiVideo() {
        System.out.println("aggiungiVideo");
        Video videoprova=new Video("Thor1","azione",15);
        cat.aggiungiVideo(videoprova);
        assertEquals(cat.getVideo(videoprova.toString()),videoprova);
    }

    /**
     * Test of toString method, of class Categoria.
     */
    @Test
    public void testToString() {
        System.out.println("toString");
      
        String expResult = "Azione";
        String result = cat.toString();
        assertEquals(expResult, result);
    }
    @Test
    public void testGetVideo(){
        Video videoprova=new Video("Thor1","azione",15);
        cat.aggiungiVideo(videoprova);
        assertEquals(videoprova,cat.getVideo("Thor1"));
    }

    /**
     * Test of getListaVideo method, of class Categoria.
     */
    
    
}
