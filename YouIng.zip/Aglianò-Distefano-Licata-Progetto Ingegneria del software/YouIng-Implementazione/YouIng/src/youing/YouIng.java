package youing;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class YouIng {
    
    /*Creazione classe YouIng come Singleton*/
    private static YouIng instance;

	private Integer idVideo;
        
	private Utente UtenteInRegistrazione;

	private Abbonamento abbonamento;
        
        private GestoreUtente gestoreUtente;

        private SezioneVideo sezioneVideo;
        
        private IDgenerator idGen;
        
        public static YouIng getInstance(){
            if(instance == null){
                //System.err.println("Istanza creata");
                instance = new YouIng();
            }
            return instance;
        }
        
        public YouIng(){
            sezioneVideo = new SezioneVideo();
            idGen = new IDgenerator();
            gestoreUtente = new GestoreUtente();
        }

	public void entraSezionePremium() {
            sezioneVideo.entraSezionePremium();
	}
        
        /* Da aggiungere al diagramma delle classi */
        public void entraSezioneStandard(){
            sezioneVideo.entraSezioneStandard();
        }

	public List<String> CercaVideo(String ParolaChiave) {
            Map<Categoria,List<Video>> mapTmp = sezioneVideo.CercaVideo(ParolaChiave);
            if(mapTmp.isEmpty()){
                return null;
            }else{
                Iterator it = sezioneVideo.CercaVideo(ParolaChiave).entrySet().iterator();
                ArrayList<Video> tmp;
                List<String> videoTrovati = new ArrayList<String>();
                String space = "                 ";
                while (it.hasNext()) {
                    Map.Entry pair = (Map.Entry)it.next();
                    tmp = (ArrayList<Video>) pair.getValue();
                    videoTrovati.add("\nCategoria: "+pair.getKey().toString());
                    for(int i=0; i<tmp.size(); i++){ 
                        videoTrovati.add(tmp.get(i).toString() + space + "ID video: " + tmp.get(i).getID());
                    }
                }
                return videoTrovati;
            }
	}

	public Video StartStreaming(Integer idVideo) {
		if(gestoreUtente.verificaAbbonamento()){
                   return sezioneVideo.startStreaming(idVideo); 
                    
                }else{
                    return null;
                }
	}

	public void StopStreaming() {

	}

	public void CaricaVideo(String nome, String descrizione) {
		idVideo = idGen.calcolaIDvideo();
                sezioneVideo.CaricaVideo(nome,descrizione,idVideo);
	}

        //Modificato l'argomento del metodo di tipo FILE e il tipo di ritorno in List<Categoria>
	public List<Categoria> ScegliVideo(File videoContent){
            return sezioneVideo.ScegliVideo(videoContent);
	}

        //Modificato il tipo di ritorno in String
	public String ScegliCategoria(Categoria nome) {
            return sezioneVideo.ScegliCategoria(nome);
	}

	public void confermaUpload(){
            sezioneVideo.confermaUpload(gestoreUtente.getNomeUtente());
	}

        /* Da aggiugnere al diagramma delle classi */
        public Catalogo getCatalogoCorrente(){
            return sezioneVideo.getCatalogoCorrente();
        }
        
        public List<Catalogo> getCatalogo(){
            return sezioneVideo.getCatalogo();
        }
}
