package youing;

import java.util.ArrayList;
import java.util.List;
//import org.apache.commons.lang3.StringUtils;

public class Categoria {

	private String NomeCategoria;

	private List<Video> listaVideo;

	private List<Video> listaVideoRicerca;
        
        public Categoria(String nome){
            this.NomeCategoria = nome;
            listaVideo = new ArrayList<Video>();
            listaVideoRicerca = new ArrayList<Video>();
        }
        
	public List<Video> Search(String ParolaChiave) {
            listaVideoRicerca.clear();
            for(int i=0; i<listaVideo.size(); i++){
                if(listaVideo.get(i).toString().contains(ParolaChiave)){
                    listaVideoRicerca.add(listaVideo.get(i));
                }
            }
            return listaVideoRicerca;
	}

	public void setVideo(String nomeVideo, String descrizione, Integer idVideo) {
            listaVideo.add(new Video(nomeVideo, descrizione, idVideo));
	}

	public void aggiungiVideo(Video usr_video) {
		listaVideo.add(usr_video);
                System.out.println(usr_video.showUserVideo());
	}
        
        //Metodo aggiunto
        public String toString(){
            return NomeCategoria;
        }
        
        public List<Video> getListaVideo()
        {
            return listaVideo;
        }
        
        public Video getVideo(String nomevideo) 
        {
            Video tmp=null;
        
            for(int i=0;i<listaVideo.size();i++)
            {
                if(listaVideo.get(i).toString().equals(nomevideo)){
                    tmp=listaVideo.get(i);
                
                }
            }
            return tmp;
        }

    public List<Video> getListaVideoRicerca() {
        return listaVideoRicerca;
    }
        
        
}