package youing;

import java.io.File;

public class Video {

	private String Nome;

	private String Descrizione;

	private Integer IDvideo;

	private String NomeUtente;
        
        private Categoria categoria_attuale;
        
        //Oggetto aggiunto da me
        private File videoContent;
        
        public Video(String nome, String descrizione, Integer IDvideo){
            this.Nome = nome;
            this.Descrizione = descrizione;
            this.IDvideo = IDvideo;
        }

        //Modificato l'argomento del metodo in tipo FILE
	public void setContent(File videoContent) {
		this.videoContent = videoContent;
	}
        
        //Metodo aggiunto durante il testing
        public File getContent(){
            return videoContent;
        }

	public void setUtente(String nomeUtente) {
		this.NomeUtente = nomeUtente;
	}
        
        public Categoria getCategoria(){
            return categoria_attuale;
        }
        
        public void setCategoria(Categoria nome){
            categoria_attuale = nome;
        }
        
        public String riepilogo(){
            String result;
            return result = "Nome file: "+Nome+"\n"+ "Descrizione: "+Descrizione;
        }
        
        //Metodo aggiunto che mi visualizza il nome del video e dell'utente che l'ha caricato
        public String showUserVideo(){
            return Nome+NomeUtente;
        }
        
        //Metodo aggiunto che mi visualizza il nome dei film in streaming
        public String toString(){
            return Nome;
        }
        
        public Integer getID(){
            return IDvideo;
        }
}
