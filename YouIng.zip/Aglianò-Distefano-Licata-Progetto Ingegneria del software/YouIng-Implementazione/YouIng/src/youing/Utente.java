package youing;

public class Utente {

	private String NomeUtente;

	private String Password;

	private String email;

	private Abbonamento abbonamento;
        
        public Utente(String nome, String password, String email, Abbonamento abbonamento){
            this.NomeUtente = nome;
            this.Password = password;
            this.email = email;
            this.abbonamento = abbonamento;
        }

	public Abbonamento getAbbonamento() {
            return abbonamento;
	}

        public String getNomeUtente() {
            return NomeUtente;
        }
}