package youing;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Catalogo {
    
        //Variabile da aggiungere
        private String nome;
    
	private List<Categoria> listaCategoria;
        private Map<Categoria,List<Video>> mapRicerca;
        
        public Catalogo(String nome){
            this.nome = nome;
            mapRicerca = new HashMap<>();
            listaCategoria = new ArrayList<>();
        }

            public Map<Categoria,List<Video>> CercaVideo(String ParolaChiave) {
            mapRicerca.clear();
            for(int i=0; i<listaCategoria.size(); i++){
               if(listaCategoria.get(i).getListaVideo().isEmpty()){
                        i++;
                }else{
                   if(!listaCategoria.get(i).Search(ParolaChiave).isEmpty()){
                       mapRicerca.put(listaCategoria.get(i), listaCategoria.get(i).Search(ParolaChiave));
                   }
                }
            } 
            return mapRicerca;
	}

	public Video Search(String IDvideo, Categoria cat) {
		return null;
	}

	public List<Categoria> getCategorie() {
		return listaCategoria;
	}
        
        public void setCategoria(String nomeCategoria){
            if(nomeCategoria.equals("Azione")){
                Categoria c = new Categoria(nomeCategoria);
                listaCategoria.add(c);
                c.setVideo("Thor", "Azione", 15);
                c.setVideo("Thor 2", "Azione", 16);
                
            }else{
                listaCategoria.add(new Categoria(nomeCategoria));
            }
        }
        
	public void aggiungiVideo(Video usr_video, Categoria categoriaScelta) {
		categoriaScelta.aggiungiVideo(usr_video);
	}

        //Metodo aggiunto
        public String toString(){
            return nome;
        }
        
        public Video trovaVideo(Integer idVideo){
            Iterator it = mapRicerca.entrySet().iterator();
            ArrayList<Video> tmp;
            Video video_tmp = null;
            while (it.hasNext()) {
                Map.Entry pair = (Map.Entry)it.next();
                tmp = (ArrayList<Video>) pair.getValue();
                for(int i=0; i<tmp.size(); i++){
                    if(tmp.get(i).getID().equals(idVideo)){
                        video_tmp = tmp.get(i);
                    }
                }
        }
            return video_tmp;
        }
        
        public Map<Categoria,List<Video>> getMapRicerca(){
            return mapRicerca;
        }
}