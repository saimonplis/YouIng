/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Matteo
 */
public class SezioneVideo {
    
    private List<Catalogo> listaCatalogo;
    
    private Catalogo catalogo_corrente;
    
    private Video video_corrente;
    
    public SezioneVideo(){
        Catalogo premium = new Catalogo("Premium");
        Catalogo standard = new Catalogo("Standard");
        listaCatalogo = new ArrayList<>();
        listaCatalogo.add(premium);
        listaCatalogo.add(standard);
        premium.setCategoria("Azione");
        premium.setCategoria("Fantasy");
        standard.setCategoria("Istruzione");
        standard.setCategoria("Divertenti");
    }
    
    public void entraSezionePremium(){
            catalogo_corrente = listaCatalogo.get(0);
    }
    
    public void entraSezioneStandard(){
            catalogo_corrente = listaCatalogo.get(1);
    }
    
    public Catalogo getCatalogoCorrente(){
        return catalogo_corrente;
    }
    
    public List<Catalogo> getCatalogo(){
        return listaCatalogo;
    }

    public Map<Categoria,List<Video>> CercaVideo(String ParolaChiave) {
        return catalogo_corrente.CercaVideo(ParolaChiave);
    }
    
    public List<Categoria> ScegliVideo(File videoContent) {
        video_corrente.setContent(videoContent);
        return catalogo_corrente.getCategorie();
    }
    
    public String ScegliCategoria(Categoria nome){
        video_corrente.setCategoria(nome);
        return video_corrente.riepilogo();
    }
    
    public void confermaUpload(String nomeUtente){
        video_corrente.setUtente(nomeUtente);
        catalogo_corrente.aggiungiVideo(video_corrente, video_corrente.getCategoria());
    }
    
    public Video CaricaVideo(String nome, String descrizione, Integer idVideo){
        return video_corrente = new Video(nome,descrizione,idVideo);
    }
    
    public Video startStreaming(Integer idVideo){
        return catalogo_corrente.trovaVideo(idVideo);
    }
    
    public Video getVideoCorrente(){
        return video_corrente;
    }
}