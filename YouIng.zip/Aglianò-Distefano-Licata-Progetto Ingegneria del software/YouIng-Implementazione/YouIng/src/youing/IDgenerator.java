/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

/**
 *
 * @author Matteo
 */
public class IDgenerator {
    
    private Integer idVideo;
    private Integer idUtente;
    
    public IDgenerator(){
        idVideo = 0;
        idUtente = 0;
    }
    
    public Integer calcolaIDvideo(){
        return idVideo = idVideo + 1;
    }  
    
    public Integer calcolaIDutente(){
        return idUtente = idUtente + 1;
    } 
}
