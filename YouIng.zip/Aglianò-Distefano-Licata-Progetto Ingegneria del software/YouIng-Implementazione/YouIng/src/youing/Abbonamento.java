package youing;
import java.util.Date;

public class Abbonamento {

	private Date dataScadenza;

	public Boolean verifica() {
		return true;
	}

}
