/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package youing;

/**
 *
 * @author Matteo
 */
public class GestoreUtente {
    
    private Utente utente_corrente;
    
    private Abbonamento abbonamento;
    
    public GestoreUtente(){
        abbonamento = new Abbonamento();
        utente_corrente = new Utente("Matteo", "1234", "abc@email.it", abbonamento);
    }
    
    public String getNomeUtente(){
        return utente_corrente.getNomeUtente();
    }
    
    //Ho modificato il tipo di ritorno in true per fare tornare a YouIng se l'abbonamento è valido(true) o no(false)
    public Boolean verificaAbbonamento(){
        abbonamento = utente_corrente.getAbbonamento();
        if(abbonamento==null){
            return false;
        }
        return abbonamento.verifica();
    }
}